clear all
close all
clc

%% Finding the images in a specific folder
path0='./synthetic/0/';
imlist0=dir ([path0,'*', '.jpg']);


path1='./synthetic/1/';
imlist1=dir ([path1,'*', '.jpg']);

%% Defining HOG Feature kernel size and Feature vector size
%% --------------------------------------------------------%%
% To find the size of feature vector, one can use the following code
img = imread([path0 imlist0(1).name]);
[hog_2x2, vis2x2] = extractHOGFeatures(im2bw(img),'CellSize',[2 2]);
[hog_4x4, vis4x4] = extractHOGFeatures(im2bw(img),'CellSize',[4 4]);
[hog_8x8, vis8x8] = extractHOGFeatures(im2bw(img),'CellSize',[8 8]);
% show the size of the HOG features
size(hog_2x2)
size(hog_4x4)
size(hog_8x8)
% Show the original image
figure;
subplot(2,3,1:3); imshow(img);

% Visualize the HOG features
subplot(2,3,4);
plot(vis2x2);
title({'CellSize = [2 2]'; ['Length = ' num2str(length(hog_2x2))]});

subplot(2,3,5);
plot(vis4x4);
title({'CellSize = [4 4]'; ['Length = ' num2str(length(hog_4x4))]});

subplot(2,3,6);
plot(vis8x8);
title({'CellSize = [8 8]'; ['Length = ' num2str(length(hog_8x8))]});
    
%% ----------------------------------------------------------------------%%
s=1;
if s==1
    cellSize = [2 2];
    featureSize=1764;
    
elseif s==2
    cellSize = [4 4];
    featureSize=324;
    
elseif s==3
    cellSize = [8 8];
    featureSize=36;
end
%% Generate HOG features for all images
trainingFeatures = zeros(202, featureSize, 'single');
c=1;
for i = 1:length(imlist0)

img = imread([path0 imlist0(i).name]);

trainingFeatures(c, :) = extractHOGFeatures(im2bw(img), 'CellSize', cellSize);
c=c+1;
end

for i = 1:length(imlist1)

img = imread([path1 imlist1(i).name]); 

trainingFeatures(c, :) = extractHOGFeatures(im2bw(img), 'CellSize', cellSize);
c=c+1;
end
%% Generate Labels: 0 for digit zero images & 1 for digit one images
trainingLabels=zeros(101,1);
trainingLabels(102:202,1)=ones(101,1); 
%% Generate the model (training)
classifier = fitcecoc(trainingFeatures, trainingLabels);

%% Test model from training Set
predictedLabels = predict(classifier, trainingFeatures(200,:))
predictedLabels = predict(classifier, trainingFeatures(50,:))

%% Digit classification using Test Set
close all
clc
path0_hand='./handwritten/0/';
imlist0_hand=dir ([path0_hand,'*', '.png']);

path1_hand='./handwritten/1/';
imlist1_hand=dir ([path1_hand,'*', '.png']);

for j=1:12
img0 = imread([path0_hand imlist0_hand(j).name]);
img1 = imread([path1_hand imlist1_hand(j).name]);


trainingFeatures0 = extractHOGFeatures(im2bw(img0,0.9), 'CellSize', cellSize);
trainingFeatures1 = extractHOGFeatures(im2bw(img1,0.9), 'CellSize', cellSize);

predictedLabels0(j) = predict(classifier, trainingFeatures0);
predictedLabels1(j) = predict(classifier, trainingFeatures1);
end
predictedLabels0
predictedLabels1