clear all
close all
clc
%% Face Recognition 
%% Load Image Information from AT&T Face Database Directory
face_data = imageSet('orl_faces','recursive');

%% Display Montage of First Face
figure;
montage(face_data(1).ImageLocation);
title('Images of first person Face');

%%  Display Query Image and Database Side by Side
Image = read(face_data(1),10); % data 1 --- image 10
figure;
for i=1:size(face_data,2)
image_list(i) = face_data(i).ImageLocation(2);
end

subplot(1,2,1);
imshow(Image);
subplot(1,2,2);
montage(image_list);

%% Split Database into 80% Training & 20% Test Sets
[training,test] = partition(face_data,[0.8 0.2]);


%% Extract and display Histogram of Oriented Gradient Features for data set 5 image 1 
[hog_2x2, vis2x2] = extractHOGFeatures(read(training(5),1),'CellSize',[2 2]);
[hog_4x4, vis4x4] = extractHOGFeatures(read(training(5),1),'CellSize',[4 4]);
[hog_8x8, vis8x8] = extractHOGFeatures(read(training(5),1),'CellSize',[8 8]);

size(hog_2x2)
size(hog_4x4)
size(hog_8x8)

figure;
subplot(2,3,1:3)
imshow(read(training(5),1));
title('Input Face');
subplot(2,3,4);
plot(vis2x2);
title({'CellSize = [2 2]'; ['Length = ' num2str(length(hog_2x2))]})

subplot(2,3,5);
plot(vis4x4);
title({'CellSize = [4 4]'; ['Length = ' num2str(length(hog_4x4))]});

subplot(2,3,6);
plot(vis8x8);
title({'CellSize = [8 8]'; ['Length = ' num2str(length(hog_8x8))]});
%% Extract HOG Features for training set 
trainingFeatures = zeros(8*40,size(hog_8x8,2));
c = 1;
for i=1:size(training,2)
    for j = 1:training(i).Count
        trainingFeatures(c,:) = extractHOGFeatures(read(training(i),j),'CellSize',[8 8]);
        label{c} = training(i).Description;    
        c = c + 1;
    end
    Index{i} = training(i).Description;
end

%% Create 40 class classifier using fitcecoc 
classifier = fitcecoc(trainingFeatures,label);


%% Test model from training Set
query_image = read(test(1),1);
query_features = extractHOGFeatures(query_image,'CellSize',[8 8]);
predictedLabels = predict(classifier,query_features);
% Map back to training set to find identity 
boolean_index = strcmp(predictedLabels, Index);
integer_index = find(boolean_index);

subplot(1,2,1);imshow(query_image);
title('Query Face');

subplot(1,2,2);imshow(read(training(integer_index),1));
title([predictedLabels 'Matched Class']);

%% Test First 10 People from Test Set
fig_number = 1;
for person=1:10
    figure
    for j = 1:test(person).Count
        query_image = read(test(person),j);
        query_features = extractHOGFeatures(query_image,'CellSize',[8 8]);
        predictedLabels = predict(classifier,query_features);
        % Map back to training set to find identity
        boolean_index = strcmp(predictedLabels, Index);
        integer_index = find(boolean_index);
        
        subplot(2,2,fig_number);imshow(imresize(query_image,3));
        title('Query Face');
        
        subplot(2,2,fig_number+1);imshow(imresize(read(training(integer_index),1),3));
        title([predictedLabels 'Matched Class']);
        fig_number = fig_number+2;
        
    end
    fig_number = 1;
end