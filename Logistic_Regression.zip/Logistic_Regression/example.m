%% ============ Part 1: Initialization ============
clear all
close all
clc

%% ============ Part 2: Load Data ============
%  The first two columns contains the exam scores and the third column
%  contains the label. 0 = not admitted & 1 = admitted

data = load('Data.txt');
X = data(:, [1, 2]); 
y = data(:, 3);

%% ============ Part 3: Plot failed and passed grades ============
% Find Indices of Positive and Negative Examples
pos = find(y == 1);
neg = find(y == 0);
% Plot admitted (positive) and non admitted (negative) students 
figure
plot(X(pos, 1), X(pos, 2), 'k+', 'LineWidth', 2, 'MarkerSize', 7);
hold on
plot(X(neg, 1), X(neg, 2), 'ko', 'MarkerFaceColor', 'y', 'MarkerSize', 7);

% Labels and Legend
hold on;
xlabel('Exam 1 score')
ylabel('Exam 2 score')
% Specified in plot order
legend('Admitted', 'Not admitted')
hold off;

%% ============ Part 4: Compute Cost and Gradient ============
%  In this part, we will implement the cost and gradient
%  for logistic regression.

%  Setup the data matrix appropriately, and add ones for the intercept term
[m, n] = size(X);

% Add intercept term to dataset X (a1 * X(:,1) + a2 * X(:,2) + 1 * a3)
X = [X ones(m, 1)];

% Initialize fitting parameters
initial_param = zeros(n + 1, 1);

% Compute and display initial cost and gradient
[cost, grad] = cost_function(initial_param, X, y);

fprintf('Cost at initial theta (zeros): %f\n', cost);
fprintf('Gradient at initial theta (zeros): \n');
fprintf(' %f \n', grad);

%% ============= Part 5: Optimizing using fminunc  =============
%  In this part, we will use a built-in function (fminunc) to find the
%  optimal parameters param.

%  Set options for fminunc
options = optimset('GradObj', 'on', 'MaxIter', 400);

%  Run fminunc to obtain the optimal param
%  This function will return param and the cost 
[param, cost] = fminunc(@(param)(cost_function(param, X, y)), initial_param, options);

% Print theta to screen
fprintf('Cost at param found by fminunc: %f\n', cost);
fprintf('param: \n');
fprintf(' %f \n', param);

% Plot Boundary
plotDecisionBoundary(param, X, y);

% Put some labels 
hold on;
% Labels and Legend
xlabel('Exam 1 score')
ylabel('Exam 2 score')

% Specified in plot order
legend('Admitted', 'Not admitted')
hold off;

%% ============== Part 6: Predict ==============
%  After learning the parameters, you'll like to use it to predict the outcomes
%  on unseen data. In this part, we will use the logistic regression model
%  to predict the probability that a student with score 53 on exam 1 and 
%  score 77 on exam 2 will be admitted.

%  Predict probability for a student with score 53 on exam 1 
%  and score 77 on exam 2 

prob = 1 ./ (1 + exp(-([53 77 1] * param)));
fprintf(['For a student with scores 53 and 77, we predict an admission ' ...
         'probability of %f\n\n'], prob);
     
     